import { clerkClient, getAuth } from "@clerk/express";
import { eq } from "drizzle-orm";
import { db, staffAccessTable } from "@workspace/db";
import type { Request } from "express";

export type StaffRole = "staff" | "admin";

const bootstrapAdmins = new Set(
  (process.env.STAFF_ADMIN_EMAILS ?? "")
    .split(",")
    .map((email) => email.trim().toLowerCase())
    .filter(Boolean),
);

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

export function isBootstrapAdmin(email: string): boolean {
  return bootstrapAdmins.has(normalizeEmail(email));
}

export async function getVerifiedPrimaryEmail(
  req: Request,
): Promise<string | null> {
  const { userId } = getAuth(req);
  if (!userId) {
    return null;
  }

  const user = await clerkClient.users.getUser(userId);
  const primaryEmail = user.primaryEmailAddress;
  if (primaryEmail?.verification?.status !== "verified") {
    return null;
  }

  return normalizeEmail(primaryEmail.emailAddress);
}

export async function getStaffRole(email: string): Promise<StaffRole | null> {
  const normalizedEmail = normalizeEmail(email);
  if (isBootstrapAdmin(normalizedEmail)) {
    return "admin";
  }

  const [record] = await db
    .select({ role: staffAccessTable.role })
    .from(staffAccessTable)
    .where(eq(staffAccessTable.email, normalizedEmail))
    .limit(1);

  return record?.role ?? null;
}

export async function listStaffMembers() {
  const records = await db
    .select({
      email: staffAccessTable.email,
      role: staffAccessTable.role,
    })
    .from(staffAccessTable)
    .orderBy(staffAccessTable.email);

  const members = new Map<
    string,
    { email: string; role: StaffRole; isBootstrap: boolean }
  >();

  for (const email of bootstrapAdmins) {
    members.set(email, { email, role: "admin", isBootstrap: true });
  }
  for (const record of records) {
    const email = normalizeEmail(record.email);
    if (!isBootstrapAdmin(email)) {
      members.set(email, { email, role: record.role, isBootstrap: false });
    }
  }

  return [...members.values()].sort((a, b) => a.email.localeCompare(b.email));
}
