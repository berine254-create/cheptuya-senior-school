import { Router, type IRouter } from "express";
import healthRouter from "./health";
import staffRouter from "./staff";
import adminRouter from "./admin";
import siteContentRouter from "./site-content";

const router: IRouter = Router();

router.use(healthRouter);
router.use(staffRouter);
router.use(adminRouter);
router.use(siteContentRouter);

export default router;
