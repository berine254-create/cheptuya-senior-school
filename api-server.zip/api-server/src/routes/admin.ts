import {
  GetAdminStaffResponse,
  RevokeAdminStaffParams,
  SetAdminStaffRoleBody,
  SetAdminStaffRoleParams,
  SetAdminStaffRoleResponse,
} from "@workspace/api-zod";
import { db, staffAccessTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  getStaffRole,
  getVerifiedPrimaryEmail,
  isBootstrapAdmin,
  listStaffMembers,
  normalizeEmail,
} from "../lib/staff-access";

const router: IRouter = Router();

async function requireAdmin(
  req: Request,
  res: Response,
): Promise<string | null> {
  const email = await getVerifiedPrimaryEmail(req);
  if (!email) {
    res.status(401).json({ error: "Authentication required." });
    return null;
  }

  if ((await getStaffRole(email)) !== "admin") {
    res.status(403).json({ error: "Administrator access required." });
    return null;
  }

  return email;
}

router.get("/admin/staff", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) {
    return;
  }

  res.json(GetAdminStaffResponse.parse({ members: await listStaffMembers() }));
});

router.put("/admin/staff/:email", async (req, res): Promise<void> => {
  const actorEmail = await requireAdmin(req, res);
  if (!actorEmail) {
    return;
  }

  const params = SetAdminStaffRoleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = SetAdminStaffRoleBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const email = normalizeEmail(params.data.email);
  if (isBootstrapAdmin(email)) {
    if (body.data.role !== "admin") {
      res.status(409).json({ error: "The bootstrap administrator cannot be changed." });
      return;
    }
    res.json(
      SetAdminStaffRoleResponse.parse({
        email,
        role: "admin",
        isBootstrap: true,
      }),
    );
    return;
  }

  const [member] = await db
    .insert(staffAccessTable)
    .values({ email, role: body.data.role, grantedBy: actorEmail })
    .onConflictDoUpdate({
      target: staffAccessTable.email,
      set: {
        role: body.data.role,
        grantedBy: actorEmail,
        updatedAt: new Date(),
      },
    })
    .returning({
      email: staffAccessTable.email,
      role: staffAccessTable.role,
    });

  res.json(
    SetAdminStaffRoleResponse.parse({
      ...member,
      isBootstrap: false,
    }),
  );
});

router.delete("/admin/staff/:email", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) {
    return;
  }

  const params = RevokeAdminStaffParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const email = normalizeEmail(params.data.email);
  if (isBootstrapAdmin(email)) {
    res.status(409).json({ error: "The bootstrap administrator cannot be removed." });
    return;
  }

  const [removed] = await db
    .delete(staffAccessTable)
    .where(eq(staffAccessTable.email, email))
    .returning({ email: staffAccessTable.email });

  if (!removed) {
    res.status(404).json({ error: "Staff account not found." });
    return;
  }

  res.sendStatus(204);
});

export default router;
