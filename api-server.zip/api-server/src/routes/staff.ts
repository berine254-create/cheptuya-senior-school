import { GetStaffAccessResponse } from "@workspace/api-zod";
import { Router, type IRouter } from "express";
import { getStaffRole, getVerifiedPrimaryEmail } from "../lib/staff-access";

const router: IRouter = Router();

router.get("/staff/access", async (req, res): Promise<void> => {
  const email = await getVerifiedPrimaryEmail(req);
  if (!email) {
    res.status(401).json({ error: "Authentication required." });
    return;
  }

  const role = await getStaffRole(email);

  const data = GetStaffAccessResponse.parse({
    isStaff: role !== null,
    isAdmin: role === "admin",
  });

  res.json(data);
});

export default router;
