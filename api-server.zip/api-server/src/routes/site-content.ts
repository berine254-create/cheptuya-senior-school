import {
  GetSiteContentResponse,
  UpdateAdminSiteContentBody,
  UpdateAdminSiteContentParams,
  UpdateAdminSiteContentResponse,
} from "@workspace/api-zod";
import { db, siteContentTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  getStaffRole,
  getVerifiedPrimaryEmail,
} from "../lib/staff-access";

const router: IRouter = Router();

async function requireAdmin(
  req: Request,
  res: Response,
): Promise<string | null> {
  const email = await getVerifiedPrimaryEmail(req);
  if (!email) {
    res.status(401).json({ error: "Authentication required." });
    return null;
  }

  if ((await getStaffRole(email)) !== "admin") {
    res.status(403).json({ error: "Administrator access required." });
    return null;
  }

  return email;
}

router.get("/site-content", async (_req, res): Promise<void> => {
  const records = await db.select().from(siteContentTable);
  res.json(
    GetSiteContentResponse.parse({
      pages: records.map(({ slug, content }) => ({ slug, content })),
    }),
  );
});

router.put("/admin/site-content/:slug", async (req, res): Promise<void> => {
  const actorEmail = await requireAdmin(req, res);
  if (!actorEmail) {
    return;
  }

  const params = UpdateAdminSiteContentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = UpdateAdminSiteContentBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const entries = Object.entries(body.data.content);
  if (
    entries.length > 80 ||
    entries.some(
      ([key, value]) =>
        !/^[A-Za-z][A-Za-z0-9_]{0,79}$/.test(key) || value.length > 4000,
    )
  ) {
    res.status(400).json({ error: "Page copy contains invalid or oversized fields." });
    return;
  }

  const [page] = await db
    .insert(siteContentTable)
    .values({
      slug: params.data.slug,
      content: body.data.content,
      updatedBy: actorEmail,
    })
    .onConflictDoUpdate({
      target: siteContentTable.slug,
      set: {
        content: body.data.content,
        updatedBy: actorEmail,
        updatedAt: new Date(),
      },
    })
    .returning({
      slug: siteContentTable.slug,
      content: siteContentTable.content,
    });

  res.json(UpdateAdminSiteContentResponse.parse(page));
});

export default router;
