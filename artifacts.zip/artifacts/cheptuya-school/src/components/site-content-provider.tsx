import { createContext, useContext, useMemo, type ReactNode } from 'react';
import {
  getGetSiteContentQueryKey,
  useGetSiteContent,
} from '@workspace/api-client-react';
import {
  DEFAULT_SITE_CONTENT,
  mergeSiteContent,
  type AllSiteCopy,
  type SitePageSlug,
} from '@/lib/siteContent';

const SiteContentContext = createContext<AllSiteCopy>(DEFAULT_SITE_CONTENT);

export function SiteContentProvider({ children }: { children: ReactNode }) {
  const { data } = useGetSiteContent({
    query: {
      queryKey: getGetSiteContentQueryKey(),
      retry: false,
      staleTime: 30_000,
    },
  });
  const content = useMemo(() => mergeSiteContent(data?.pages), [data]);

  return (
    <SiteContentContext.Provider value={content}>
      {children}
    </SiteContentContext.Provider>
  );
}

export function usePageCopy(page: SitePageSlug) {
  return useContext(SiteContentContext)[page];
}
