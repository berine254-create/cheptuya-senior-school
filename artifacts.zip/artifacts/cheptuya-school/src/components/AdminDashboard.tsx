import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  getGetAdminStaffQueryKey,
  getGetSiteContentQueryKey,
  getGetStaffAccessQueryKey,
  useGetAdminStaff,
  useGetSiteContent,
  useGetStaffAccess,
  useRevokeAdminStaff,
  useSetAdminStaffRole,
  useUpdateAdminSiteContent,
  type AdminStaffMember,
  type SitePageSlug,
} from '@workspace/api-client-react';
import {
  AlertCircle,
  ArrowUpRight,
  BookOpen,
  Check,
  ChevronDown,
  CircleHelp,
  FileText,
  Globe2,
  KeyRound,
  LoaderCircle,
  LockKeyhole,
  Mail,
  Menu,
  PencilLine,
  Plus,
  Save,
  Shield,
  ShieldCheck,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import './AdminDashboard.css';

type Role = 'staff' | 'admin';
type PageMap = Record<SitePageSlug, Record<string, string>>;

type AdminDashboardProps = {
  defaultContent: PageMap;
};

const pageDetails: { slug: SitePageSlug; label: string; description: string }[] = [
  { slug: 'home', label: 'Home', description: 'The first welcome families see.' },
  { slug: 'about', label: 'About', description: 'Our school story and values.' },
  { slug: 'academics', label: 'Academics', description: 'Learning, subjects and support.' },
  { slug: 'admissions', label: 'Admissions', description: 'Joining Cheptuya Senior School.' },
  { slug: 'contact', label: 'Contact', description: 'Where to find and reach us.' },
];

const errorMessage = (error: unknown, fallback: string) =>
  error instanceof Error ? error.message : fallback;

function initials(email: string) {
  return email.slice(0, 1).toUpperCase();
}

function prettyField(key: string) {
  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/[_-]/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function StatusMessage({
  tone,
  children,
  onDismiss,
}: {
  tone: 'success' | 'error' | 'info';
  children: ReactNode;
  onDismiss?: () => void;
}) {
  return (
    <div className={`adm-notice adm-notice--${tone}`} role={tone === 'error' ? 'alert' : 'status'}>
      {tone === 'success' ? <Check size={17} /> : <AlertCircle size={17} />}
      <span>{children}</span>
      {onDismiss && (
        <button className="adm-notice-dismiss" onClick={onDismiss} aria-label="Dismiss message">
          <X size={15} />
        </button>
      )}
    </div>
  );
}

export default function AdminDashboard({ defaultContent }: AdminDashboardProps) {
  const queryClient = useQueryClient();
  const access = useGetStaffAccess();
  const staffQuery = useGetAdminStaff({
    query: {
      queryKey: getGetAdminStaffQueryKey(),
      enabled: access.data?.isAdmin === true,
      retry: false,
    },
  });
  const contentQuery = useGetSiteContent({
    query: {
      queryKey: getGetSiteContentQueryKey(),
      enabled: access.data?.isAdmin === true,
      retry: false,
    },
  });
  const setStaffRole = useSetAdminStaffRole();
  const revokeStaff = useRevokeAdminStaff();
  const saveContent = useUpdateAdminSiteContent();

  const [section, setSection] = useState<'staff' | 'pages'>('staff');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<Role>('staff');
  const [emailError, setEmailError] = useState('');
  const [selectedPage, setSelectedPage] = useState<SitePageSlug>('home');
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [notice, setNotice] = useState<{ tone: 'success' | 'error'; text: string } | null>(null);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [confirmRevoke, setConfirmRevoke] = useState<string | null>(null);

  const members = staffQuery.data?.members ?? [];
  const pageData = contentQuery.data?.pages ?? [];
  const currentPage = pageDetails.find((page) => page.slug === selectedPage)!;

  const mergedPageContent = useMemo(() => {
    const saved = pageData.find((page) => page.slug === selectedPage)?.content ?? {};
    return { ...(defaultContent[selectedPage] ?? {}), ...saved };
  }, [defaultContent, pageData, selectedPage]);

  useEffect(() => {
    setDraft(mergedPageContent);
  }, [mergedPageContent]);

  const dirty = Object.keys({ ...mergedPageContent, ...draft }).some(
    (key) => (draft[key] ?? '') !== (mergedPageContent[key] ?? ''),
  );

  async function handleGrant(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const cleanEmail = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setEmailError('Enter a valid email address, such as name@school.org.');
      return;
    }
    setEmailError('');
    setNotice(null);
    try {
      await setStaffRole.mutateAsync({ email: cleanEmail, data: { role } });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getGetAdminStaffQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetStaffAccessQueryKey() }),
      ]);
      setEmail('');
      setRole('staff');
      setNotice({ tone: 'success', text: `${cleanEmail} now has ${role} access.` });
    } catch (error) {
      setNotice({ tone: 'error', text: errorMessage(error, 'Access could not be updated. Try again.') });
    }
  }

  async function handleRevoke(member: AdminStaffMember) {
    if (member.isBootstrap) return;
    setNotice(null);
    try {
      await revokeStaff.mutateAsync({ email: member.email });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getGetAdminStaffQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetStaffAccessQueryKey() }),
      ]);
      setNotice({ tone: 'success', text: `Access removed for ${member.email}.` });
      setConfirmRevoke(null);
    } catch (error) {
      setNotice({ tone: 'error', text: errorMessage(error, 'Access could not be removed. Try again.') });
    }
  }

  async function handleChangeRole(member: AdminStaffMember, nextRole: Role) {
    if (member.isBootstrap || member.role === nextRole) return;
    setNotice(null);
    try {
      await setStaffRole.mutateAsync({ email: member.email, data: { role: nextRole } });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getGetAdminStaffQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetStaffAccessQueryKey() }),
      ]);
      setNotice({ tone: 'success', text: `${member.email} is now ${nextRole === 'admin' ? 'an administrator' : 'staff'}.` });
    } catch (error) {
      setNotice({ tone: 'error', text: errorMessage(error, `The role for ${member.email} could not be changed.`) });
    }
  }

  async function handleSavePage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNotice(null);
    try {
      await saveContent.mutateAsync({ slug: selectedPage, data: { content: draft } });
      await queryClient.invalidateQueries({ queryKey: getGetSiteContentQueryKey() });
      setNotice({ tone: 'success', text: `${currentPage.label} copy has been saved.` });
    } catch (error) {
      setNotice({ tone: 'error', text: errorMessage(error, 'The page copy was not saved. Try again.') });
    }
  }

  const accessLoading = access.isLoading;
  if (accessLoading) {
    return (
      <main className="adm-loading-screen">
        <div className="adm-loading-mark"><BookOpen size={22} /></div>
        <div className="adm-skeleton adm-skeleton--title" />
        <div className="adm-skeleton adm-skeleton--line" />
        <span>Opening the school office…</span>
      </main>
    );
  }

  if (access.isError) {
    return (
      <main className="adm-state-screen">
        <div className="adm-state-icon adm-state-icon--error"><AlertCircle size={23} /></div>
        <h1>We couldn’t confirm your access</h1>
        <p>Check your connection and try again. Your school workspace remains protected.</p>
        <button className="adm-button adm-button--primary" onClick={() => access.refetch()}>Try again</button>
      </main>
    );
  }

  if (!access.data?.isAdmin) {
    return (
      <main className="adm-state-screen">
        <div className="adm-state-icon"><LockKeyhole size={23} /></div>
        <p className="adm-overline">Cheptuya Senior School</p>
        <h1>This office is for administrators</h1>
        <p>Your account does not have permission to manage staff access or public school information.</p>
        <div className="adm-support-note"><CircleHelp size={16} /> Ask a school administrator if you need access.</div>
      </main>
    );
  }

  return (
    <div className="adm-shell">
      <aside className={`adm-sidebar${mobileNavOpen ? ' adm-sidebar--open' : ''}`}>
        <div className="adm-brand">
          <div className="adm-brand-mark"><BookOpen size={23} strokeWidth={1.8} /></div>
          <div>
            <strong>Cheptuya</strong>
            <span>Senior School</span>
          </div>
          <button className="adm-close-nav" onClick={() => setMobileNavOpen(false)} aria-label="Close navigation">
            <X size={18} />
          </button>
        </div>

        <div className="adm-workspace-label">School office</div>
        <nav className="adm-nav" aria-label="Administration">
          <button className={`adm-nav-item${section === 'staff' ? ' is-active' : ''}`} onClick={() => { setSection('staff'); setMobileNavOpen(false); }}>
            <Users size={18} /><span>Staff access</span><span className="adm-nav-count">{members.length}</span>
          </button>
          <button className={`adm-nav-item${section === 'pages' ? ' is-active' : ''}`} onClick={() => { setSection('pages'); setMobileNavOpen(false); }}>
            <FileText size={18} /><span>Website pages</span><span className="adm-nav-count">5</span>
          </button>
        </nav>

        <div className="adm-sidebar-note">
          <div className="adm-sidebar-note-icon"><ShieldCheck size={17} /></div>
          <div><strong>Trusted hands</strong><p>Changes here are reflected on the school website.</p></div>
        </div>

        <div className="adm-sidebar-footer">
          <div className="adm-footer-seal">C</div>
          <div><strong>Cheptuya Senior School</strong><span>Administration workspace</span></div>
        </div>
      </aside>
      {mobileNavOpen && <button className="adm-scrim" onClick={() => setMobileNavOpen(false)} aria-label="Close navigation overlay" />}

      <main className="adm-main">
        <header className="adm-topbar">
          <button className="adm-menu-button" onClick={() => setMobileNavOpen(true)} aria-label="Open navigation"><Menu size={20} /></button>
          <div className="adm-breadcrumb"><span>School office</span><span className="adm-breadcrumb-slash">/</span><strong>{section === 'staff' ? 'Staff access' : 'Website pages'}</strong></div>
          <div className="adm-topbar-right">
            <span className="adm-secure-indicator"><span /> Secure workspace</span>
            <div className="adm-profile"><span className="adm-profile-avatar">A</span><span>Administrator</span><ChevronDown size={15} /></div>
          </div>
        </header>

        <div className="adm-content">
          <div className="adm-page-heading">
            <div>
              <p className="adm-overline">Cheptuya Senior School <span>/</span> Administration</p>
              <h1>{section === 'staff' ? 'Staff access' : 'Website pages'}</h1>
              <p className="adm-heading-description">
                {section === 'staff'
                  ? 'Give trusted colleagues the right level of access to the school workspace.'
                  : 'Keep the information families see on the school website clear and up to date.'}
              </p>
            </div>
            <a className="adm-view-site" href={import.meta.env.BASE_URL} target="_blank" rel="noreferrer"><Globe2 size={16} /> View public site <ArrowUpRight size={14} /></a>
          </div>

          {notice && <StatusMessage tone={notice.tone} onDismiss={() => setNotice(null)}>{notice.text}</StatusMessage>}

          {section === 'staff' ? (
            <section className="adm-section-content" aria-label="Staff access management">
              <div className="adm-summary-row">
                <div className="adm-summary-intro">
                  <div className="adm-summary-icon"><KeyRound size={18} /></div>
                  <div><strong>Access is granted by email</strong><p>Only people you approve can enter the administration workspace.</p></div>
                </div>
                <div className="adm-summary-total"><span>Approved accounts</span><strong>{members.length.toString().padStart(2, '0')}</strong></div>
              </div>

              <div className="adm-staff-layout">
                <section className="adm-panel adm-member-panel">
                  <div className="adm-panel-heading">
                    <div><h2>Approved staff</h2><p>People with permission to sign in.</p></div>
                    <span className="adm-count-pill">{members.length} {members.length === 1 ? 'person' : 'people'}</span>
                  </div>
                  {staffQuery.isLoading ? (
                    <div className="adm-table-loading" aria-label="Loading approved staff">
                      {[1, 2, 3].map((item) => <div className="adm-member-skeleton" key={item}><i /><span /><b /></div>)}
                    </div>
                  ) : staffQuery.isError ? (
                    <div className="adm-inline-error"><AlertCircle size={17} /><div><strong>Staff list unavailable</strong><span>We couldn’t load approved accounts.</span></div><button onClick={() => staffQuery.refetch()}>Try again</button></div>
                  ) : members.length === 0 ? (
                    <div className="adm-empty">
                      <div className="adm-empty-mark"><Users size={22} /></div>
                      <strong>No approved staff yet</strong>
                      <p>Add a colleague using their school email address. They can sign in as soon as access is granted.</p>
                    </div>
                  ) : (
                    <div className="adm-member-list">
                      <div className="adm-list-labels"><span>Person</span><span>Role</span><span>Access</span><span /></div>
                      {members.map((member) => (
                        <div className="adm-member-row" key={member.email}>
                          <div className="adm-member-person">
                            <span className={`adm-member-avatar${member.role === 'admin' ? ' adm-member-avatar--admin' : ''}`}>{initials(member.email)}</span>
                            <span className="adm-member-email">{member.email}{member.isBootstrap && <small>Founding administrator</small>}</span>
                          </div>
                          {member.isBootstrap ? (
                            <span className={`adm-role-badge${member.role === 'admin' ? ' adm-role-badge--admin' : ''}`}>
                              <Shield size={13} />Admin
                            </span>
                          ) : (
                            <label className={`adm-role-select${member.role === 'admin' ? ' adm-role-select--admin' : ''}`} aria-label={`Role for ${member.email}`}>
                              {member.role === 'admin' ? <Shield size={13} /> : <Users size={13} />}
                              <select value={member.role} disabled={setStaffRole.isPending} onChange={(event) => handleChangeRole(member, event.target.value as Role)}>
                                <option value="staff">Staff</option>
                                <option value="admin">Admin</option>
                              </select>
                              <ChevronDown size={12} />
                            </label>
                          )}
                          <span className="adm-access-status"><i /> Active</span>
                          {member.isBootstrap ? (
                            <span className="adm-protected" title="The founding administrator is protected"><LockKeyhole size={14} /><span>Protected</span></span>
                          ) : confirmRevoke === member.email ? (
                            <span className="adm-confirm-actions">
                      <button className="adm-confirm-yes" disabled={revokeStaff.isPending} onClick={() => handleRevoke(member)}>{revokeStaff.isPending ? 'Removing…' : 'Remove'}</button>
                              <button className="adm-confirm-no" onClick={() => setConfirmRevoke(null)}>Keep</button>
                            </span>
                          ) : (
                            <button className="adm-icon-button" onClick={() => setConfirmRevoke(member.email)} aria-label={`Remove ${member.email}`} title="Remove access"><Trash2 size={16} /></button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="adm-panel-footnote"><LockKeyhole size={14} /> Protected administrator accounts cannot be removed.</div>
                </section>

                <section className="adm-panel adm-grant-panel">
                  <div className="adm-form-heading">
                    <div className="adm-form-mark"><Plus size={19} /></div>
                    <div><h2>Grant access</h2><p>Add a colleague to the approved list.</p></div>
                  </div>
                  <form onSubmit={handleGrant} noValidate>
                    <label className="adm-label" htmlFor="adm-email">School email address</label>
                    <div className={`adm-input-wrap${emailError ? ' has-error' : ''}`}>
                      <Mail size={17} />
                      <input id="adm-email" type="email" autoComplete="email" placeholder="colleague@cheptuya.ac.ke" value={email} onChange={(event) => { setEmail(event.target.value); setEmailError(''); }} aria-invalid={!!emailError} aria-describedby={emailError ? 'adm-email-error' : undefined} />
                    </div>
                    {emailError && <p className="adm-field-error" id="adm-email-error">{emailError}</p>}
                    <label className="adm-label" htmlFor="adm-role">Access level</label>
                    <div className="adm-select-wrap">
                      <select id="adm-role" value={role} onChange={(event) => setRole(event.target.value as Role)}>
                        <option value="staff">Staff — approved workspace access</option>
                        <option value="admin">Administrator — manage access and pages</option>
                      </select><ChevronDown size={16} />
                    </div>
                    <div className="adm-role-guidance"><ShieldCheck size={15} /><span>Administrators can grant access and edit public website copy.</span></div>
                    <button className="adm-button adm-button--primary adm-grant-button" type="submit" disabled={setStaffRole.isPending}>
                      {setStaffRole.isPending ? <LoaderCircle className="adm-spin" size={17} /> : <Plus size={17} />}
                      {setStaffRole.isPending ? 'Granting access…' : 'Grant access'}
                    </button>
                  </form>
                </section>
              </div>
              <div className="adm-help-strip"><div className="adm-help-symbol"><ShieldCheck size={18} /></div><p><strong>Keep access close to the work.</strong> Grant administrator access only to colleagues responsible for staff permissions or public school information.</p><button onClick={() => setSection('pages')}>Review website pages <ArrowUpRight size={14} /></button></div>
            </section>
          ) : (
            <section className="adm-section-content" aria-label="Website page copy editor">
              <div className="adm-copy-layout">
                <aside className="adm-page-list-panel">
                  <div className="adm-panel-heading adm-page-list-heading"><div><h2>Public pages</h2><p>Select a page to edit its copy.</p></div></div>
                  <nav className="adm-page-nav" aria-label="Public website pages">
                    {pageDetails.map((page) => (
                      <button className={`adm-page-nav-item${selectedPage === page.slug ? ' is-active' : ''}`} key={page.slug} onClick={() => { setSelectedPage(page.slug); setNotice(null); }}>
                        <span className="adm-page-nav-icon"><FileText size={16} /></span><span className="adm-page-nav-copy"><strong>{page.label}</strong><small>{page.description}</small></span><ArrowUpRight size={14} className="adm-page-nav-arrow" />
                      </button>
                    ))}
                  </nav>
                  <div className="adm-page-list-foot"><Globe2 size={15} /><span>Updates appear on the public school website.</span></div>
                </aside>

                <section className="adm-panel adm-editor-panel">
                  <div className="adm-editor-heading">
                    <div>
                      <div className="adm-editor-title-line"><span className="adm-editor-icon"><PencilLine size={17} /></span><h2>{currentPage.label}</h2><span className="adm-page-live"><i /> Public page</span></div>
                      <p>{currentPage.description} Edit the text below, then save your changes.</p>
                    </div>
                    <span className="adm-editor-slug">/{selectedPage === 'home' ? '' : selectedPage}</span>
                  </div>
                  {contentQuery.isError ? (
                    <div className="adm-content-fetch-error">
                      <StatusMessage tone="error">Saved page copy could not be loaded. Defaults are shown; retry before saving so existing edits are not overwritten.</StatusMessage>
                      <button className="adm-button adm-button--outline" onClick={() => contentQuery.refetch()}>Retry loading saved copy</button>
                    </div>
                  ) : contentQuery.isLoading ? (
                    <div className="adm-editor-skeleton" aria-label="Loading saved page copy"><div /><div /><div /><div /></div>
                  ) : (
                    <form className="adm-copy-form" onSubmit={handleSavePage}>
                      {Object.entries(draft).map(([key, value]) => {
                        const multiLine = value.length > 100 || /description|body|story|message|intro|mission|vision/i.test(key);
                        return (
                          <label className="adm-copy-field" key={key}>
                            <span className="adm-label">{prettyField(key)}</span>
                            {multiLine ? (
                              <textarea value={value} rows={value.length > 250 ? 6 : 4} onChange={(event) => setDraft((previous) => ({ ...previous, [key]: event.target.value }))} />
                            ) : (
                              <input type="text" value={value} onChange={(event) => setDraft((previous) => ({ ...previous, [key]: event.target.value }))} />
                            )}
                            <span className="adm-field-hint">{key === 'title' || key.toLowerCase().includes('heading') ? 'A clear, welcoming heading works best.' : 'This text is visible to families and the wider community.'}</span>
                          </label>
                        );
                      })}
                      {Object.keys(draft).length === 0 && (
                        <div className="adm-empty adm-editor-empty"><div className="adm-empty-mark"><FileText size={22} /></div><strong>No default copy configured</strong><p>There are no editable fields for this page yet. Add default page fields to make this section editable.</p></div>
                      )}
                      <div className="adm-editor-footer">
                        <div className="adm-save-state">{dirty ? <><span className="adm-unsaved-dot" /> Unsaved changes</> : <><Check size={15} /> All changes saved</>}</div>
                        <button className="adm-button adm-button--primary" type="submit" disabled={!dirty || saveContent.isPending || Object.keys(draft).length === 0 || contentQuery.isError}>
                          {saveContent.isPending ? <LoaderCircle className="adm-spin" size={17} /> : <Save size={17} />}
                          {saveContent.isPending ? 'Saving copy…' : 'Save changes'}
                        </button>
                      </div>
                    </form>
                  )}
                </section>
              </div>
              <div className="adm-copy-note"><div className="adm-copy-note-icon"><FileText size={17} /></div><p><strong>Starting copy is already in place.</strong> The editor combines the school’s default text with any saved changes, so even a new page is ready to update.</p></div>
            </section>
          )}

          <footer className="adm-footer"><span>Cheptuya Senior School</span><span>Administration workspace <i /> Private and secure</span></footer>
        </div>
      </main>
    </div>
  );
}
