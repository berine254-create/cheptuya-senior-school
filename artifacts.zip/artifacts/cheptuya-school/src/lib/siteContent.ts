export type SitePageSlug =
  | 'home'
  | 'about'
  | 'academics'
  | 'admissions'
  | 'contact';

export type SitePageCopy = Record<string, string>;
export type AllSiteCopy = Record<SitePageSlug, SitePageCopy>;

export const DEFAULT_SITE_CONTENT: AllSiteCopy = {
  home: {
    heroHeading: 'Shaping confident minds for a',
    heroAccent: 'brighter future.',
    heroDescription:
      'At Cheptuya Senior School, we nurture academic excellence, personal growth, strong values, and future-ready skills so every learner can thrive with purpose and confidence.',
    missionHeading: 'Learn well.\nLive with purpose.',
    missionParagraphOne:
      'Cheptuya Senior School is a place where learners grow in confidence, character, and capability. We blend rigorous academics with holistic development and community values.',
    missionParagraphTwo:
      'Our students are encouraged to think critically, act with integrity, and prepare for life beyond the classroom with courage and purpose.',
    prioritiesHeading: 'Room to grow in\nevery direction.',
    prioritiesDescription:
      'Learning reaches beyond a single measure. We create space for knowledge, character, imagination, and meaningful contribution.',
    experienceHeading: 'Learning that inspires confidence and purpose.',
    experienceDescription:
      'We foster a supportive environment where students are encouraged to think critically, act responsibly, and grow with courage.',
    voicesHeading: 'A community that sees\nthe whole learner.',
    voicesDescription:
      'Stories of confidence, care, and progress from the people who make this community.',
  },
  about: {
    heroHeading: 'A strong foundation\nfor',
    heroAccent: 'what comes next.',
    heroDescription:
      'We bring academic ambition and care for the whole learner together—building confidence, character, and capability for a life of purpose.',
    missionHeading: 'Empowering students to learn, lead, and thrive.',
    missionParagraphOne:
      'Cheptuya Senior School is a place where learners grow in confidence, character, and capability. We blend rigorous academics with holistic development and community values.',
    missionParagraphTwo:
      'Our students are encouraged to think critically, act with integrity, and prepare for life beyond the classroom with courage and purpose.',
    guidingHeading:
      'Excellence is more than a result. It is how we learn, live, and show up for one another.',
    guidingDescription:
      'Belonging, service, responsibility, wellbeing, and curiosity are part of the education we believe in.',
    valuesIntro:
      'Strong values shape the way we learn together and take responsibility for the wider community.',
  },
  academics: {
    heroHeading: 'Learning for a',
    heroAccent: 'fuller future.',
    heroDescription:
      'Strong academic foundations, joined with curiosity, creative opportunity, character, and the practical capabilities learners carry into life.',
    focusHeading: 'The whole learner,\nalways in view.',
    focusDescription:
      'Learning is built through connected priorities—not one pathway or one kind of talent.',
    learningHeading: 'Curiosity, courage, and a place to belong.',
    learningDescription:
      'We foster a supportive environment where students are encouraged to think critically, act responsibly, and grow with courage.',
  },
  admissions: {
    heroHeading: 'A good next step\nstarts with a',
    heroAccent: 'hello.',
    heroDescription:
      "Choosing a school is a conversation. Reach out to learn more about Cheptuya Senior School, ask questions, and explore whether our approach is right for your learner.",
    stepsHeading: 'Three simple ways\nto begin.',
    stepsDescription:
      'There is no online application form here. Connect directly with the school and take the next step together.',
    stepOneTitle: 'Get in touch',
    stepOneDescription:
      'Call or email the school to introduce your family and tell us what you would like to know.',
    stepTwoTitle: 'Ask your questions',
    stepTwoDescription:
      'Start a conversation about learning, student life, and the areas that matter to your family.',
    stepThreeTitle: 'Explore a visit',
    stepThreeDescription:
      'Speak with the school about arranging a visit and seeing the community for yourself.',
    closingHeading: 'A whole-person education, grounded in possibility.',
    closingDescription:
      'Cheptuya Senior School brings together academic excellence, holistic development, community engagement, and future readiness.',
  },
  contact: {
    heroHeading: "Let's start a",
    heroAccent: 'conversation.',
    heroDescription:
      'Questions about the school, learning, or getting to know the community? Reach out directly using the contact details below.',
    contactHeading: 'Choose the way\nthat works for you.',
    contactDescription:
      'Questions about learning, student life, or arranging a visit? Contact the school directly.',
    schoolEmail: 'info@cheptuyasenior.ac.ke',
    schoolPhone: '+254 700 000 000',
    schoolAddress: '123 Cheptuya Road',
    familyHeading: 'Curious about the next step?',
    familyDescription:
      'Tell us what you are looking for and speak directly with the school. We can help you learn more about the academic approach, student experience, and admissions.',
    approachHeading: 'Academic excellence. Character. Future readiness.',
    approachDescription:
      'A community-minded education with the whole learner in view.',
  },
};

export function mergeSiteContent(
  pages: Array<{ slug: SitePageSlug; content: SitePageCopy }> | undefined,
): AllSiteCopy {
  const merged: AllSiteCopy = {
    home: { ...DEFAULT_SITE_CONTENT.home },
    about: { ...DEFAULT_SITE_CONTENT.about },
    academics: { ...DEFAULT_SITE_CONTENT.academics },
    admissions: { ...DEFAULT_SITE_CONTENT.admissions },
    contact: { ...DEFAULT_SITE_CONTENT.contact },
  };

  for (const page of pages ?? []) {
    merged[page.slug] = { ...merged[page.slug], ...page.content };
  }

  return merged;
}
