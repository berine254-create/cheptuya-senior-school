import {
  Fragment,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  getGetStaffAccessQueryKey,
  useGetStaffAccess,
} from '@workspace/api-client-react';
import AdminDashboard from '@/components/AdminDashboard';
import {
  SiteContentProvider,
  usePageCopy,
} from '@/components/site-content-provider';
import { DEFAULT_SITE_CONTENT } from '@/lib/siteContent';
import {
  ClerkProvider,
  SignIn,
  SignUp,
  useAuth,
  useClerk,
  useUser,
} from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import {
  ArrowRight, BookOpen, Check, HeartHandshake, Lightbulb,
  LogOut, Mail, MapPin, Menu, Phone, ShieldCheck, Users, X,
} from 'lucide-react';
import {
  Link,
  Redirect,
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';
import studentsPhoto from './assets/students.jpg';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY for Clerk sign-in.');
}

function stripBase(path: string) {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#173d32',
    colorForeground: '#173d32',
    colorMutedForeground: '#64736a',
    colorDanger: '#a83b2c',
    colorBackground: '#fbf8ef',
    colorInput: '#fffdf7',
    colorInputForeground: '#173d32',
    colorNeutral: '#cfc8b8',
    fontFamily: "'DM Sans', sans-serif",
    borderRadius: '0.6rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center px-4',
    cardBox:
      'bg-[#fbf8ef] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#d9d2c3] shadow-lg',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#173d32] font-serif text-2xl',
    headerSubtitle: 'text-[#64736a]',
    socialButtonsBlockButtonText: 'text-[#173d32] font-semibold',
    formFieldLabel: 'text-[#173d32] font-medium',
    footerActionLink: 'text-[#a76431] font-semibold',
    footerActionText: 'text-[#64736a]',
    dividerText: 'text-[#64736a]',
    identityPreviewEditButton: 'text-[#a76431] font-semibold',
    formFieldSuccessText: 'text-[#245c43]',
    alertText: 'text-[#7d2d24]',
    logoBox: 'rounded-full overflow-hidden',
    logoImage: 'object-contain',
    socialButtonsBlockButton:
      'border border-[#d9d2c3] bg-[#fffdf7] hover:bg-[#f1ebdc]',
    formButtonPrimary:
      'bg-[#173d32] hover:bg-[#245c43] text-[#fbf8ef] font-semibold',
    formFieldInput:
      'bg-[#fffdf7] text-[#173d32] border-[#cfc8b8] focus:border-[#a76431]',
    footerAction: 'text-[#64736a]',
    dividerLine: 'bg-[#d9d2c3]',
    alert: 'bg-[#f8e7e1] border border-[#e8c3b8]',
    otpCodeFieldInput:
      'bg-[#fffdf7] text-[#173d32] border-[#cfc8b8]',
    formFieldRow: 'text-[#173d32]',
    main: 'text-[#173d32]',
  },
};

const pageMeta: Record<string, { title: string; description: string }> = {
  '/': { title: 'Cheptuya Senior School | A future with purpose', description: 'Cheptuya Senior School — academic excellence, holistic development, community engagement, and future readiness.' },
  '/about': { title: 'Our mission & values | Cheptuya Senior School', description: 'Meet the mission and values shaping confident, capable, and community-minded learners at Cheptuya Senior School.' },
  '/academics': { title: 'Learning priorities | Cheptuya Senior School', description: 'Explore the academic, personal, creative, and future-ready learning priorities at Cheptuya Senior School.' },
  '/admissions': { title: 'Admissions | Cheptuya Senior School', description: 'Find out how to inquire, connect with Cheptuya Senior School, and take the next step for your learner.' },
  '/contact': { title: 'Contact Cheptuya Senior School', description: 'Get in touch with Cheptuya Senior School by email, phone, or at 123 Cheptuya Road.' },
  '/staff': { title: 'Staff area | Cheptuya Senior School', description: 'Secure staff access for Cheptuya Senior School.' },
  '/admin': { title: 'Administration | Cheptuya Senior School', description: 'Manage staff access and public school information.' },
  '/sign-in': { title: 'Staff sign in | Cheptuya Senior School', description: 'Sign in to the Cheptuya Senior School staff area.' },
  '/sign-up': { title: 'Staff account | Cheptuya Senior School', description: 'Create an account to request access to the Cheptuya Senior School staff area.' },
};

function Metadata() {
  const [location] = useLocation();
  useEffect(() => {
    const metadataPath = location.startsWith('/sign-in')
      ? '/sign-in'
      : location.startsWith('/sign-up')
        ? '/sign-up'
        : location;
    const meta = pageMeta[metadataPath] ?? { title: 'Page not found | Cheptuya Senior School', description: 'Explore Cheptuya Senior School.' };
    document.title = meta.title;
    let description = document.querySelector('meta[name="description"]');
    if (!description) {
      description = document.createElement('meta');
      description.setAttribute('name', 'description');
      document.head.appendChild(description);
    }
    description.setAttribute('content', meta.description);
  }, [location]);
  return null;
}

const navigation = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About' },
  { href: '/academics', label: 'Academics' },
  { href: '/admissions', label: 'Admissions' },
  { href: '/contact', label: 'Contact' },
];

function Header() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const { isLoaded, isSignedIn } = useAuth();
  const contactCopy = usePageCopy('contact');
  const { data: staffAccess } = useGetStaffAccess({
    query: {
      queryKey: getGetStaffAccessQueryKey(),
      enabled: isLoaded && Boolean(isSignedIn),
      retry: false,
    },
  });
  useEffect(() => setOpen(false), [location]);
  return (
    <>
      <div className="topline">
        <div className="container topline-inner">
          <span>Learning with purpose · Growing together</span>
          <span><a href={`tel:${contactCopy.schoolPhone.replace(/[^\d+]/g, '')}`}>{contactCopy.schoolPhone}</a> &nbsp;·&nbsp; {contactCopy.schoolAddress}</span>
        </div>
      </div>
      <header className="site-header">
        <div className="container nav">
          <Link href="/" className="brand" aria-label="Cheptuya Senior School home" data-testid="link-brand">
            <span className="brand-mark">CS</span><span>Cheptuya Senior School</span>
          </Link>
          <button className="menu-toggle" onClick={() => setOpen(!open)} aria-expanded={open} aria-label={open ? 'Close menu' : 'Open menu'} data-testid="button-menu">
            {open ? <X size={23} /> : <Menu size={23} />}
          </button>
          <nav className={`nav-links${open ? ' is-open' : ''}`} aria-label="Main navigation">
            {navigation.map(item => (
              <Link key={item.href} href={item.href} className={location === item.href ? 'active' : ''} data-testid={`link-nav-${item.label.toLowerCase()}`}>
                {item.label}
              </Link>
            ))}
            {isLoaded && (
              <Link
                href={isSignedIn ? '/staff' : '/sign-in'}
                className="nav-staff"
                data-testid="link-staff-access"
              >
                {isSignedIn ? 'Staff area' : 'Staff sign in'}
                <ArrowRight size={14} />
              </Link>
            )}
            {staffAccess?.isAdmin && (
              <Link href="/admin" className="nav-staff" data-testid="link-admin-dashboard">
                Admin dashboard <ArrowRight size={14} />
              </Link>
            )}
            <Link href="/admissions#inquire" className="nav-apply" data-testid="link-apply-nav">Start a conversation <ArrowRight size={15} /></Link>
          </nav>
        </div>
      </header>
    </>
  );
}

function Footer() {
  const contactCopy = usePageCopy('contact');
  return (
    <>
      <section className="cta-band">
        <div className="container cta-inner">
          <div><h2>A school where every learner can find their way forward.</h2><p>Discover a whole-person education grounded in learning, character, and possibility.</p></div>
          <Link href="/admissions#inquire" className="button-dark" data-testid="link-cta-admissions">Explore admissions <ArrowRight size={16} /></Link>
        </div>
      </section>
      <footer className="footer">
        <div className="container footer-grid">
          <div className="footer-brand">Cheptuya Senior School<p>Inspiring academic excellence, character, and future-ready learners.</p></div>
          <div className="footer-col"><h4>Explore</h4><ul><li><Link href="/about">Our mission</Link></li><li><Link href="/academics">Learning priorities</Link></li><li><Link href="/contact">School life</Link></li></ul></div>
          <div className="footer-col"><h4>For families</h4><ul><li><Link href="/admissions">How to inquire</Link></li><li><Link href="/admissions#visit">Plan a visit</Link></li><li><Link href="/contact">Contact the school</Link></li></ul></div>
          <div className="footer-col"><h4>Find us</h4><ul><li>{contactCopy.schoolAddress}</li><li><a href={`mailto:${contactCopy.schoolEmail}`}>{contactCopy.schoolEmail}</a></li><li><a href={`tel:${contactCopy.schoolPhone.replace(/[^\d+]/g, '')}`}>{contactCopy.schoolPhone}</a></li></ul></div>
        </div>
        <div className="container footer-bottom"><span>© 2026 Cheptuya Senior School. All rights reserved.</span><span>Academic excellence · Character · Future readiness</span></div>
      </footer>
    </>
  );
}

function Shell({ children }: { children: ReactNode }) {
  return <div className="site-shell"><Metadata /><Header />{children}<Footer /></div>;
}

function Home() {
  const copy = usePageCopy('home');
  const priorities = [
    { icon: <BookOpen size={22} strokeWidth={1.5} />, title: 'Academic excellence', text: 'Engaging and rigorous learning that builds understanding, curiosity, and confidence.' },
    { icon: <HeartHandshake size={22} strokeWidth={1.5} />, title: 'Whole-person growth', text: 'Character, leadership, wellbeing, and resilience nurtured alongside academics.' },
    { icon: <Lightbulb size={22} strokeWidth={1.5} />, title: 'Innovation & STEM', text: 'Digital confidence and practical problem-solving skills for the future.' },
    { icon: <Users size={22} strokeWidth={1.5} />, title: 'Community', text: 'Service learning and meaningful connection grow empathy and responsibility.' },
  ];
  const voices = [
    { initial: 'A', quote: '“Cheptuya Senior School has helped our child grow in confidence, discipline, and academic focus. The school genuinely cares about the whole child.”', name: 'Mrs. Achieng', role: 'Parent' },
    { initial: 'J', quote: '“I feel supported and challenged every day. The teachers encourage us to do our best and become leaders in our own way.”', name: 'John', role: 'Student' },
    { initial: 'M', quote: '“The school combines strong academic standards with care, values, and community engagement. It prepares students for life beyond school.”', name: 'Mr. Kibet', role: 'Parent' },
  ];
  return <Shell>
    <main>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-copy reveal">
            <span className="eyebrow">Academic excellence · Whole-person education</span>
            <h1><Multiline value={copy.heroHeading} /> <em>{copy.heroAccent}</em></h1>
            <p>{copy.heroDescription}</p>
            <div className="hero-actions">
              <Link href="/academics" className="button-primary" data-testid="link-explore-programs">Explore learning <ArrowRight size={16} /></Link>
              <Link href="/about" className="text-link" data-testid="link-learn-about">Our approach <ArrowRight size={14} /></Link>
            </div>
            <div className="stats-row">
              <div className="stat"><strong>98%</strong><span>Parent satisfaction</span></div>
              <div className="stat"><strong>25+</strong><span>Activities</span></div>
              <div className="stat"><strong>12:1</strong><span>Support ratio</span></div>
            </div>
            <small style={{ display: 'block', marginTop: 12, color: '#879087', fontSize: 9 }}>Figures shown as supplied draft content.</small>
          </div>
          <div className="hero-art reveal-delay">
            <span className="art-index">A SCHOOL FOR WHAT COMES NEXT</span>
            <div className="hero-photo"><img src={studentsPhoto} alt="Students learning and working together in a classroom" /></div>
            <div className="hero-seal">Curious<br />minds<br />at work</div>
            <div className="photo-note"><span>Student growth · Draft figure</span><strong>+42%<br />academic confidence</strong></div>
          </div>
        </div>
      </section>
      <section className="mission section">
        <div className="container mission-layout">
          <div className="mission-side"><span className="section-label">A clear purpose</span><h2 className="section-title"><Multiline value={copy.missionHeading} /></h2><Link href="/about" className="text-link" style={{ color: '#f6f2e8' }} data-testid="link-about-mission">Our mission & values <ArrowRight size={14} /></Link></div>
          <div>
            <p>{copy.missionParagraphOne}</p>
            <p>{copy.missionParagraphTwo}</p>
            <div className="values-grid">
              <div className="value"><b>Academic excellence</b><span>Strong foundations for success and lifelong learning.</span></div>
              <div className="value"><b>Holistic growth</b><span>Wellbeing, confidence, and personal development matter.</span></div>
              <div className="value"><b>Community</b><span>Belonging, service, and shared responsibility.</span></div>
              <div className="value"><b>Future readiness</b><span>Innovation, digital literacy, and practical problem-solving.</span></div>
            </div>
          </div>
        </div>
      </section>
      <section className="priorities section">
        <div className="container">
          <div className="section-head"><div><span className="section-label">Our learning priorities</span><h2 className="section-title"><Multiline value={copy.prioritiesHeading} /></h2></div><p>{copy.prioritiesDescription}</p></div>
          <div className="priority-grid">{priorities.map((item, i) => <article className="priority-card" key={item.title}><span className="priority-num">0{i + 1}</span><div className="priority-icon">{item.icon}</div><h3>{item.title}</h3><p>{item.text}</p></article>)}</div>
        </div>
      </section>
      <section className="experience">
        <div className="experience-image"><img src={studentsPhoto} alt="A collaborative classroom moment at Cheptuya Senior School" /></div>
        <div className="experience-copy"><span className="section-label">The student experience</span><h2>{copy.experienceHeading}</h2><p>{copy.experienceDescription}</p>
          <ul className="check-list">
            <li><span className="check-dot"><Check size={12} /></span><span>Inquiry-led learning that develops curiosity and understanding.</span></li>
            <li><span className="check-dot"><Check size={12} /></span><span>Leadership and service opportunities that build character.</span></li>
            <li><span className="check-dot"><Check size={12} /></span><span>Technology and creative learning for future readiness.</span></li>
            <li><span className="check-dot"><Check size={12} /></span><span>A safe, inclusive, and nurturing community for every learner.</span></li>
          </ul>
          <div style={{ marginTop: 28 }}><Link href="/academics" className="text-link" data-testid="link-student-experience">See our learning priorities <ArrowRight size={14} /></Link></div>
        </div>
      </section>
      <section className="voices section">
        <div className="container">
          <div className="section-head"><div><span className="section-label">Parent & student voices</span><h2 className="section-title"><Multiline value={copy.voicesHeading} /></h2></div><p>{copy.voicesDescription}</p></div>
          <div className="voices-grid">{voices.map(voice => <article className="voice" key={voice.name}><div><div className="quote-mark">“</div><blockquote>{voice.quote}</blockquote></div><div className="voice-person"><span className="voice-avatar">{voice.initial}</span><span><b>{voice.name}</b><small>{voice.role} · supplied draft testimonial</small></span></div></article>)}</div>
        </div>
      </section>
    </main>
  </Shell>;
}

function Multiline({ value }: { value: string }) {
  return <>{value.split('\n').map((line, index) => <Fragment key={`${index}-${line}`}>{index > 0 && <br />}{line}</Fragment>)}</>;
}

function PageHero({ label, title, accent, description }: { label: string; title: string; accent: string; description: string }) {
  return <section className="page-hero"><div className="container page-heading"><span className="eyebrow">{label}</span><h1><Multiline value={title} /> <em>{accent}</em></h1><p>{description}</p></div></section>;
}

function About() {
  const copy = usePageCopy('about');
  return <Shell><main>
    <PageHero label="About Cheptuya" title={copy.heroHeading} accent={copy.heroAccent} description={copy.heroDescription} />
    <section className="section"><div className="container page-columns">
      <div className="content-copy"><span className="section-label">Our mission</span><h2>{copy.missionHeading}</h2><p>{copy.missionParagraphOne}</p><p>{copy.missionParagraphTwo}</p><Link href="/academics" className="text-link" data-testid="link-about-academics">Explore our learning priorities <ArrowRight size={14} /></Link></div>
      <aside className="editorial-card"><span className="section-label">What guides us</span><h3>{copy.guidingHeading}</h3><p>{copy.guidingDescription}</p></aside>
    </div></section>
    <section className="mission section"><div className="container mission-layout"><div className="mission-side"><span className="section-label">Our values</span><h2 className="section-title">Character in action.</h2></div><div><p>{copy.valuesIntro}</p><div className="values-grid">
      <div className="value"><b>Integrity</b><span>Think critically and act with honesty.</span></div><div className="value"><b>Respect</b><span>Recognize the dignity and potential of each person.</span></div><div className="value"><b>Accountability</b><span>Take responsibility for choices and shared spaces.</span></div><div className="value"><b>Discipline</b><span>Build the focus and resilience to keep growing.</span></div>
    </div></div></div></section>
  </main></Shell>;
}

function Academics() {
  const copy = usePageCopy('academics');
  const items = [
    ['01', 'Academic excellence', 'Engaging and rigorous learning builds understanding, curiosity, and confidence. Strong foundations support success and lifelong learning.'],
    ['02', 'Whole-person growth', 'Character, leadership, wellbeing, and resilience grow alongside academic learning. Every learner is known, encouraged, and supported toward meaningful growth.'],
    ['03', 'Innovation & STEM', 'Students build digital confidence and practical problem-solving skills through technology and creative learning.'],
    ['04', 'Creative opportunities', 'Arts, leadership, sports, and technology create room for every student to shine.'],
    ['05', 'Community engagement', 'Service learning and meaningful community connection grow empathy, belonging, and shared responsibility.'],
  ];
  return <Shell><main>
    <PageHero label="Academics & beyond" title={copy.heroHeading} accent={copy.heroAccent} description={copy.heroDescription} />
    <section className="academics-focus"><div className="container">
      <div className="section-head"><div><span className="section-label">Our focus</span><h2 className="section-title"><Multiline value={copy.focusHeading} /></h2></div><p>{copy.focusDescription}</p></div>
      <div className="focus-list">{items.map(([number, title, text]) => <article className="focus-item" key={number}><span className="number">{number}</span><h3>{title}</h3><p>{text}</p></article>)}</div>
    </div></section>
    <section className="experience">
      <div className="experience-image"><img src={studentsPhoto} alt="Learners sharing ideas in a classroom" /></div>
      <div className="experience-copy"><span className="section-label">How we learn</span><h2>{copy.learningHeading}</h2><p>{copy.learningDescription}</p>
        <ul className="check-list"><li><span className="check-dot"><Check size={12} /></span><span>Inquiry-led learning that develops curiosity and understanding.</span></li><li><span className="check-dot"><Check size={12} /></span><span>Leadership and service opportunities that build character.</span></li><li><span className="check-dot"><Check size={12} /></span><span>Technology and creative learning for future readiness.</span></li></ul>
      </div>
    </section>
  </main></Shell>;
}

function Admissions() {
  const copy = usePageCopy('admissions');
  const contactCopy = usePageCopy('contact');
  return <Shell><main>
    <PageHero label="Admissions" title={copy.heroHeading} accent={copy.heroAccent} description={copy.heroDescription} />
    <section className="section" id="inquire"><div className="container">
      <div className="section-head"><div><span className="section-label">Getting started</span><h2 className="section-title"><Multiline value={copy.stepsHeading} /></h2></div><p>{copy.stepsDescription}</p></div>
      <div className="admissions-steps">
        <article className="step"><span className="step-count">STEP 01</span><h3>{copy.stepOneTitle}</h3><p>{copy.stepOneDescription}</p><a className="text-link" href={`mailto:${contactCopy.schoolEmail}`} data-testid="link-admissions-email">Email the school <ArrowRight size={14} /></a></article>
        <article className="step" id="visit"><span className="step-count">STEP 02</span><h3>{copy.stepTwoTitle}</h3><p>{copy.stepTwoDescription}</p><Link className="text-link" href="/contact" data-testid="link-admissions-contact">Contact options <ArrowRight size={14} /></Link></article>
        <article className="step"><span className="step-count">STEP 03</span><h3>{copy.stepThreeTitle}</h3><p>{copy.stepThreeDescription}</p><a className="text-link" href={`tel:${contactCopy.schoolPhone.replace(/[^\d+]/g, '')}`} data-testid="link-admissions-call">Call {contactCopy.schoolPhone} <ArrowRight size={14} /></a></article>
      </div>
    </div></section>
    <section className="priorities section"><div className="container page-columns"><div className="content-copy"><span className="section-label">What matters here</span><h2>{copy.closingHeading}</h2><p>{copy.closingDescription}</p><p>Explore the learning priorities and values that shape the student experience before getting in touch.</p><Link href="/academics" className="button-primary" data-testid="link-admissions-academics">Explore academics <ArrowRight size={16} /></Link></div><aside className="editorial-card"><span className="section-label">Ready to talk?</span><h3>We would be glad to hear from you.</h3><p>Use the school's provided contact details to ask a question or discuss a visit. No form submission or online application is required.</p><a href={`mailto:${contactCopy.schoolEmail}`} className="text-link" data-testid="link-admissions-mailto">{contactCopy.schoolEmail} <ArrowRight size={14} /></a></aside></div></section>
  </main></Shell>;
}

function Contact() {
  const copy = usePageCopy('contact');
  return <Shell><main>
    <PageHero label="Contact" title={copy.heroHeading} accent={copy.heroAccent} description={copy.heroDescription} />
    <section className="section"><div className="container contact-layout">
      <div><span className="section-label">Reach the school</span><h2 className="section-title"><Multiline value={copy.contactHeading} /></h2><p>{copy.contactDescription}</p><div className="contact-options">
        <a href={`mailto:${copy.schoolEmail}`} className="contact-option" data-testid="link-contact-email"><Mail className="contact-option-icon" size={22} strokeWidth={1.5} /><span><small>Email</small><strong>{copy.schoolEmail}</strong></span><ArrowRight size={16} /></a>
        <a href={`tel:${copy.schoolPhone.replace(/[^\d+]/g, '')}`} className="contact-option" data-testid="link-contact-phone"><Phone className="contact-option-icon" size={22} strokeWidth={1.5} /><span><small>Call</small><strong>{copy.schoolPhone}</strong></span><ArrowRight size={16} /></a>
      </div></div>
      <div className="address-card"><div><span className="section-label">Come say hello</span><h2>Cheptuya Senior School</h2><p>{copy.schoolAddress}</p></div><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'end' }}><span style={{ color: '#d1d9ce', fontSize: 12 }}>For inquiries and visit arrangements, please get in touch.</span><MapPin size={30} color="#d8a849" strokeWidth={1.3} /></div></div>
    </div></section>
    <section className="priorities section"><div className="container page-columns"><div className="content-copy"><span className="section-label">For families</span><h2>{copy.familyHeading}</h2><p>{copy.familyDescription}</p><Link href="/admissions" className="button-primary" data-testid="link-contact-admissions">Admissions information <ArrowRight size={16} /></Link></div><aside className="editorial-card"><span className="section-label">Our approach</span><h3>{copy.approachHeading}</h3><p>{copy.approachDescription}</p><Link href="/about" className="text-link" data-testid="link-contact-about">Get to know Cheptuya <ArrowRight size={14} /></Link></aside></div></section>
  </main></Shell>;
}

function AuthLoading({ message }: { message: string }) {
  return (
    <main className="auth-page">
      <Metadata />
      <Link className="auth-brand" href="/" aria-label="Cheptuya Senior School home">
        <span className="brand-mark">CS</span>
        <span>Cheptuya Senior School</span>
      </Link>
      <div className="auth-loading-wrap">
        <span className="section-label">Private staff access</span>
        <div className="auth-loading" role="status" aria-live="polite">
          <span className="auth-loading-mark" aria-hidden="true"><ShieldCheck size={21} /></span>
          {message}
        </div>
        <Link className="auth-home-link" href="/">Return to the public school website</Link>
      </div>
    </main>
  );
}

function AuthPageShell({
  children,
  title,
  description,
}: {
  children: ReactNode;
  title: string;
  description: string;
}) {
  return (
    <main className="auth-page">
      <Metadata />
      <Link className="auth-brand" href="/">
        <span className="brand-mark">CS</span>
        <span>Cheptuya Senior School</span>
      </Link>
      <div className="auth-layout">
        <div className="auth-intro">
          <span className="auth-overline">CHEPTUYA · STAFF PORTAL</span>
          <span className="section-label">Private staff access</span>
          <h1 id="auth-title">{title}</h1>
          <p>{description}</p>
          <div className="auth-trust-note">
            <span className="auth-trust-icon" aria-hidden="true"><ShieldCheck size={18} /></span>
            <span>Access is reserved for individually approved staff accounts.</span>
          </div>
        </div>
        <div className="auth-widget" role="region" aria-label="Staff account form">{children}</div>
      </div>
      <Link className="auth-home-link" href="/" data-testid="link-auth-home">Return to the public school website</Link>
    </main>
  );
}

function SignInPage() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <AuthLoading message="Preparing secure sign in…" />;
  if (isSignedIn) return <Redirect to="/staff" />;

  return (
    <AuthPageShell
      title="Welcome back."
      description="Sign in with your approved school account to enter the staff area."
    >
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        forceRedirectUrl={`${basePath}/staff`}
      />
    </AuthPageShell>
  );
}

function SignUpPage() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <AuthLoading message="Preparing secure sign up…" />;
  if (isSignedIn) return <Redirect to="/staff" />;

  return (
    <AuthPageShell
      title="Create a staff account."
      description="Only the individually approved staff account can enter the protected staff area."
    >
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
        forceRedirectUrl={`${basePath}/staff`}
      />
    </AuthPageShell>
  );
}

function StaffPortal() {
  const { isLoaded, isSignedIn } = useAuth();
  const { user } = useUser();
  const { signOut } = useClerk();
  const { data, isLoading, isError } = useGetStaffAccess({
    query: {
      enabled: isLoaded && Boolean(isSignedIn),
      queryKey: getGetStaffAccessQueryKey(),
      retry: false,
    },
  });

  if (!isLoaded) return <AuthLoading message="Checking your session…" />;
  if (!isSignedIn) return <Redirect to="/sign-in" />;

  return (
    <Shell>
      <main className="staff-page">
        <div className="container">
          <section className="staff-card" aria-labelledby="staff-title">
            <span className="section-label">Cheptuya Senior School</span>
            {isLoading ? (
              <div className="staff-status" role="status" data-testid="status-staff-access">Checking staff access…</div>
            ) : isError ? (
              <div className="staff-notice" role="alert">
                <h1 id="staff-title">We couldn’t verify access.</h1>
                <p>Please try again. Your account has not been granted access while verification is unavailable.</p>
              </div>
            ) : data?.isStaff ? (
              <div className="staff-notice">
                <div className="staff-icon"><ShieldCheck size={24} /></div>
                <h1 id="staff-title">Welcome{user?.firstName ? `, ${user.firstName}` : ' back'}.</h1>
                <p>Your account is approved for the Cheptuya Senior School staff area.</p>
                <div className="staff-account">
                  <span>Signed in as</span>
                  <strong>{user?.primaryEmailAddress?.emailAddress ?? 'School staff'}</strong>
                </div>
              </div>
            ) : (
              <div className="staff-notice" role="alert">
                <h1 id="staff-title">This account isn’t approved for staff access.</h1>
                <p>Sign in with the approved staff account or contact the school administrator.</p>
                <div className="staff-account">
                  <span>Signed in as</span>
                  <strong>{user?.primaryEmailAddress?.emailAddress ?? 'Unverified account'}</strong>
                </div>
              </div>
            )}
            <div className="staff-actions">
              <Link href="/academics" className="text-link">Explore the public school site <ArrowRight size={14} /></Link>
              <button
                className="staff-signout"
                type="button"
                onClick={() => signOut({ redirectUrl: basePath || '/' })}
                data-testid="button-staff-signout"
              >
                Sign out <LogOut size={15} />
              </button>
            </div>
          </section>
        </div>
      </main>
    </Shell>
  );
}

function AdminPortal() {
  const { isLoaded, isSignedIn } = useAuth();

  if (!isLoaded) return <AuthLoading message="Preparing the administration workspace…" />;
  if (!isSignedIn) return <Redirect to="/sign-in" />;

  return <AdminDashboard defaultContent={DEFAULT_SITE_CONTENT} />;
}

function HomeRedirect() {
  const { isLoaded, isSignedIn } = useAuth();
  if (isLoaded && isSignedIn) return <Redirect to="/staff" />;
  return <Home />;
}

function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={HomeRedirect} />
    <Route path="/about" component={About} />
    <Route path="/academics" component={Academics} />
    <Route path="/admissions" component={Admissions} />
    <Route path="/contact" component={Contact} />
    <Route path="/staff" component={StaffPortal} />
    <Route path="/admin" component={AdminPortal} />
    <Route path="/sign-in/*?" component={SignInPage} />
    <Route path="/sign-up/*?" component={SignUpPage} />
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const previousUserId = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (previousUserId.current !== undefined && previousUserId.current !== userId) {
        queryClient.clear();
      }
      previousUserId.current = userId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);

  return null;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: 'Staff sign in',
            subtitle: 'Sign in with your approved school account.',
          },
        },
        signUp: {
          start: {
            title: 'Create a staff account',
            subtitle: 'Only the approved staff account can access the staff area.',
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <ClerkQueryClientCacheInvalidator />
      <SiteContentProvider>
        <Router />
      </SiteContentProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={basePath}>
          <ClerkProviderWithRoutes />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
